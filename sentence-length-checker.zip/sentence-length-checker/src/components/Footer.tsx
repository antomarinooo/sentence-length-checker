import { Github, Mail, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { useLanguage } from './LanguageProvider';

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="mt-12 sm:mt-16 border-t bg-muted/30">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {/* About Section */}
          <div className="space-y-3 sm:space-y-4">
            <h3 className="font-medium text-sm sm:text-base">{t.footer.about}</h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {t.footer.description}
            </p>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <span>{t.footer.madeWith}</span>
              <Heart className="h-3 w-3 fill-red-500 text-red-500" />
            </div>
          </div>

          {/* Contact Section */}
          <div className="space-y-3 sm:space-y-4">
            <h3 className="font-medium text-sm sm:text-base">{t.footer.contact}</h3>
            <div className="flex flex-col space-y-2 sm:space-y-3">
              <Button
                variant="outline"
                size="sm"
                className="justify-start w-full sm:w-fit h-10 sm:h-9 text-xs sm:text-sm"
                onClick={() => window.open('https://github.com/yourusername/sentence-analyzer', '_blank')}
              >
                <Github className="h-4 w-4 mr-2 flex-shrink-0" />
                <span className="truncate">{t.footer.github}</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="justify-start w-full sm:w-fit h-10 sm:h-9 text-xs sm:text-sm"
                onClick={() => window.open('mailto:your.email@example.com?subject=Sentence Length Analyzer', '_blank')}
              >
                <Mail className="h-4 w-4 mr-2 flex-shrink-0" />
                <span className="truncate">your.email@example.com</span>
              </Button>
            </div>
          </div>
        </div>

        <Separator className="my-6 sm:my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center text-xs text-muted-foreground space-y-2 md:space-y-0 text-center md:text-left">
          <p>© 2025 Sentence Length Analyzer. Open source project.</p>
          <p className="text-center md:text-right">Privacy-focused • No data collection • Client-side processing only</p>
        </div>
      </div>
    </footer>
  );
}